create
    definer = root@localhost procedure PROC_DELETEMARK(IN p_studentId varchar(4))
BEGIN
    DELETE FROM Mark
    WHERE studentId = p_studentId;
END;

