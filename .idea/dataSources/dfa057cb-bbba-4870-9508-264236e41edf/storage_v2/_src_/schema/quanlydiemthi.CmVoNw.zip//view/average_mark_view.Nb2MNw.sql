create definer = root@localhost view average_mark_view as
select `quanlydiemthi`.`student`.`studentId`   AS `studentId`,
       `quanlydiemthi`.`student`.`studentName` AS `studentName`,
       avg(`quanlydiemthi`.`mark`.`point`)     AS `Điểm trung bình các môn học`
from (`quanlydiemthi`.`student` join `quanlydiemthi`.`mark`
      on ((`quanlydiemthi`.`student`.`studentId` = `quanlydiemthi`.`mark`.`studentId`)))
group by `quanlydiemthi`.`student`.`studentId`, `quanlydiemthi`.`student`.`studentName`;

