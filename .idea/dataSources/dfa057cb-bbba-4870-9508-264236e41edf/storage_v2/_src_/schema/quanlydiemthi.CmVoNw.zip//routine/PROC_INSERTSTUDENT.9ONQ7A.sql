create
    definer = root@localhost procedure PROC_INSERTSTUDENT(IN p_studentId varchar(4), IN p_studentName varchar(100),
                                                          IN p_birthday date, IN p_gender bit, IN p_address text,
                                                          IN p_phoneNumber varchar(45))
BEGIN
    INSERT INTO Student(studentId, studentName, birthday, gender, address, phoneNumber)
    VALUES (p_studentId, p_studentName, p_birthday, p_gender, p_address, p_phoneNumber);
END;

