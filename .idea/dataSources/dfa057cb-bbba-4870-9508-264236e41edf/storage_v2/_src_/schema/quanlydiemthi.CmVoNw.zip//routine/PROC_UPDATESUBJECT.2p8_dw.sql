create
    definer = root@localhost procedure PROC_UPDATESUBJECT(IN p_subjectId varchar(4), IN p_newSubjectName varchar(45))
BEGIN
    UPDATE Subject
    SET subjectName = p_newSubjectName
    WHERE subjectId = p_subjectId;
END;

