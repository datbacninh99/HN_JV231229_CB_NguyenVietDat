create definer = root@localhost view student_view as
select `quanlydiemthi`.`student`.`studentId`                                         AS `studentId`,
       `quanlydiemthi`.`student`.`studentName`                                       AS `studentName`,
       (case when (`quanlydiemthi`.`student`.`gender` = 1) then 'Nam' else 'Nữ' end) AS `gender`,
       `quanlydiemthi`.`student`.`address`                                           AS `hometown`
from `quanlydiemthi`.`student`;

